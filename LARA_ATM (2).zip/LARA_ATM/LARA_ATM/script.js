let account = localStorage.getItem("account");
let password = localStorage.getItem("password");

let money = Number(localStorage.getItem("money")) || 0;

let transactions =
    JSON.parse(localStorage.getItem("transactions")) || [];

let currentTransaction = "";


/* CREATE ACCOUNT */

function createAccount() {

    let accountNumber =
        document.getElementById("accountNumber").value;

    let createPassword =
        document.getElementById("createPassword").value;

    let message =
        document.getElementById("createMessage");


    if (accountNumber === "" || createPassword === "") {

        message.innerText =
            "Please fill all fields.";

        message.style.color = "#ff6666";

        return;
    }


    localStorage.setItem("account", accountNumber);
    localStorage.setItem("password", createPassword);
    localStorage.setItem("money", 0);
    localStorage.setItem("transactions", JSON.stringify([]));

    account = accountNumber;
    password = createPassword;
    money = 0;
    transactions = [];


    message.innerText =
        "Account created successfully!";

    message.style.color = "#00ffaa";


    setTimeout(() => {

        showLogin();

    }, 1200);
}


/* SHOW LOGIN */

function showLogin() {

    document
        .getElementById("createSection")
        .classList.add("hidden");

    document
        .getElementById("loginSection")
        .classList.remove("hidden");
}


/* SHOW CREATE */

function showCreate() {

    document
        .getElementById("loginSection")
        .classList.add("hidden");

    document
        .getElementById("createSection")
        .classList.remove("hidden");
}


/* LOGIN */

function login() {

    let loginAccount =
        document.getElementById("loginAccount").value;

    let loginPassword =
        document.getElementById("loginPassword").value;

    let message =
        document.getElementById("loginMessage");


    if (
        loginAccount === account &&
        loginPassword === password
    ) {

        document
            .getElementById("authPage")
            .classList.add("hidden");

        document
            .getElementById("dashboard")
            .classList.remove("hidden");

        updateBalance();

    } else {

        message.innerText =
            "Invalid account number or password.";

        message.style.color = "#ff6666";
    }
}


/* LOGOUT */

function logout() {

    document
        .getElementById("dashboard")
        .classList.add("hidden");

    document
        .getElementById("authPage")
        .classList.remove("hidden");

    document
        .getElementById("loginAccount").value = "";

    document
        .getElementById("loginPassword").value = "";
}


/* UPDATE BALANCE */

function updateBalance() {

    document
        .getElementById("balance")
        .innerText = money.toLocaleString();

    localStorage.setItem("money", money);
}


/* OPEN DEPOSIT */

function openDeposit() {

    currentTransaction = "deposit";

    document
        .getElementById("transactionTitle")
        .innerText = "Deposit Money";

    document
        .getElementById("transactionButton")
        .innerText = "Deposit";

    document
        .getElementById("transactionBox")
        .classList.remove("hidden");

    clearTransactionFields();
}


/* OPEN WITHDRAW */

function openWithdraw() {

    currentTransaction = "withdraw";

    document
        .getElementById("transactionTitle")
        .innerText = "Withdraw Money";

    document
        .getElementById("transactionButton")
        .innerText = "Withdraw";

    document
        .getElementById("transactionBox")
        .classList.remove("hidden");

    clearTransactionFields();
}


/* PERFORM TRANSACTION */

function performTransaction() {

    let amount =
        Number(document.getElementById("amount").value);

    let enteredPassword =
        document
        .getElementById("transactionPassword")
        .value;

    let message =
        document.getElementById("transactionMessage");


    if (amount <= 0) {

        message.innerText =
            "Enter a valid amount.";

        message.style.color = "#ff6666";

        return;
    }


    if (enteredPassword !== password) {

        message.innerText =
            "Wrong password.";

        message.style.color = "#ff6666";

        return;
    }


    /* DEPOSIT */

    if (currentTransaction === "deposit") {

        money += amount;

        transactions.push({
            type: "Deposit",
            amount: amount,
            date: new Date().toLocaleString()
        });

        message.innerText =
            "₹" + amount +
            " successfully deposited.";

        message.style.color = "#00ffaa";
    }


    /* WITHDRAW */

    else if (currentTransaction === "withdraw") {

        if (money < amount) {

            message.innerText =
                "Insufficient funds.";

            message.style.color = "#ff6666";

            return;
        }


        money -= amount;

        transactions.push({
            type: "Withdraw",
            amount: amount,
            date: new Date().toLocaleString()
        });

        message.innerText =
            "₹" + amount +
            " successfully withdrawn.";

        message.style.color = "#00ffaa";
    }


    localStorage.setItem("money", money);

    localStorage.setItem(
        "transactions",
        JSON.stringify(transactions)
    );

    updateBalance();

    setTimeout(() => {

        closeTransaction();

    }, 1200);
}


/* DISPLAY BALANCE */

function displayBalance() {

    updateBalance();

    alert(
        "Your current balance is ₹" +
        money.toLocaleString()
    );
}


/* OPEN STATEMENT */

function openStatement() {

    let statementBox =
        document.getElementById("statementBox");

    let statementList =
        document.getElementById("statementList");


    statementList.innerHTML = "";


    if (transactions.length === 0) {

        statementList.innerHTML =
            `<p style="color:#8299b4">
                No transactions yet.
             </p>`;

    } else {

        transactions.forEach(transaction => {

            let className =
                transaction.type === "Deposit"
                ? "deposit"
                : "withdraw";


            let sign =
                transaction.type === "Deposit"
                ? "+"
                : "-";


            statementList.innerHTML += `

                <div class="statement-item">

                    <div>
                        <strong class="${className}">
                            ${transaction.type}
                        </strong>

                        <br>

                        <small>
                            ${transaction.date}
                        </small>
                    </div>

                    <strong class="${className}">
                        ${sign} ₹${transaction.amount}
                    </strong>

                </div>
            `;
        });
    }


    document
        .getElementById("statementBalance")
        .innerText = money.toLocaleString();


    statementBox.classList.remove("hidden");
}


/* CLOSE STATEMENT */

function closeStatement() {

    document
        .getElementById("statementBox")
        .classList.add("hidden");
}


/* CLOSE TRANSACTION */

function closeTransaction() {

    document
        .getElementById("transactionBox")
        .classList.add("hidden");

    clearTransactionFields();
}


/* CLEAR FIELDS */

function clearTransactionFields() {

    document.getElementById("amount").value = "";

    document
        .getElementById("transactionPassword")
        .value = "";

    document
        .getElementById("transactionMessage")
        .innerText = "";
}